# Tightly Glossary Trainer — shared leaderboard on Vercel

Study game with **one shared leaderboard** the whole team sees from a single link.
Hosted on Vercel; scores stored in **Upstash Redis** (free tier). No local dev
tools needed — deploy from GitHub in the browser.

## Files

```
glossary-trainer-vercel/
├─ index.html        ← the game (unchanged; calls /api/scores)
├─ api/
│  └─ scores.js      ← serverless function: GET/POST the leaderboard
├─ package.json      ← marks the project (no dependencies, no build step)
└─ README.md
```

---

## Deploy (browser only, ~10 min)

### 1. Put these files in a GitHub repo
1. On github.com: **New repository** → name it `glossary-trainer` → Create.
2. On the repo page: **Add file → Upload files**.
3. Drag in **`index.html`**, **`package.json`**, and the **`api`** folder
   (keep the folder — `api/scores.js` must stay inside `api/`). Chrome lets you
   drag the whole folder and preserves the structure.
4. **Commit changes.**

### 2. Import the repo into Vercel
1. Go to https://vercel.com and **Sign up / Log in with GitHub**.
2. **Add New… → Project** → find `glossary-trainer` → **Import**.
3. Framework Preset: **Other** (leave build settings empty). Click **Deploy**.
4. You'll get a URL like `glossary-trainer.vercel.app`. The game loads, but the
   leaderboard won't work until the next step (no database yet).

### 3. Add the database (Upstash Redis)
1. Open the project → **Storage** tab → **Create Database** (or **Connect
   Store**) → choose **Upstash for Redis** (Marketplace).
2. Accept the free plan and connect it to this project. Vercel automatically adds
   the Redis credentials as **environment variables** to the project.

### 4. Redeploy so the function sees the env vars
Env vars only apply to a new deployment:
- **Deployments** tab → newest deployment → **⋯ → Redeploy**.

### 5. Test, then share
- Open your `*.vercel.app` URL, play a quiz, hit **Save to leaderboard**, open the
  **Leaderboard** tab — your run should appear.
- Open the same URL in another browser/incognito to confirm it's shared.
- **Share the URL with your team.**

---

## If the leaderboard says "Redis env vars not found"
The Upstash integration names its variables slightly differently across accounts.
This function already accepts the common ones (`UPSTASH_REDIS_REST_URL` /
`UPSTASH_REDIS_REST_TOKEN` and `KV_REST_API_URL` / `KV_REST_API_TOKEN`). If yours
differ:
1. Project → **Settings → Environment Variables** — look at what the integration
   added (there'll be a REST URL and a REST token).
2. Either add two variables named `UPSTASH_REDIS_REST_URL` and
   `UPSTASH_REDIS_REST_TOKEN` with those same values, **or** tell me the exact
   names you see and I'll match the code to them.
3. **Redeploy** after any env-var change.

## Notes
- **Who can post:** anyone with the link (no login) — fine for an internal team.
- **Moderating / resetting:** delete or edit the `board` key in the Upstash
  console (**Data Browser**), or ask me to add a passcode-protected reset.
- **Capacity:** keeps the top 100 runs (`MAX` in `api/scores.js`).
- **Custom domain:** add one under the project's **Domains** settings.
